import torch
from model import get_model
from PIL import Image
from torchvision.transforms import ToTensor
import matplotlib.pyplot as plt
import matplotlib.patches as patches

def load_model(device, model_path='insulator_detector.pth'):
    model = get_model(num_classes=2)  # Background + insulator
    model.load_state_dict(torch.load(model_path))
    model.to(device)
    model.eval()
    return model

def predict_and_display(model, img_path, device):
    img = Image.open(img_path).convert("RGB")
    img_tensor = ToTensor()(img).unsqueeze(0).to(device)

    with torch.no_grad():
        predictions = model(img_tensor)
    
    boxes = predictions[0]['boxes'].cpu().numpy()
    scores = predictions[0]['scores'].cpu().numpy()
    score_threshold = 0.5
    boxes = boxes[scores >= score_threshold]

    fig, ax = plt.subplots(1)
    ax.imshow(img)

    for box in boxes:
        xmin, ymin, xmax, ymax = box
        rect = patches.Rectangle((xmin, ymin), xmax - xmin, ymax - ymin,
                                 linewidth=2, edgecolor='r', facecolor='none')
        ax.add_patch(rect)

    plt.show()
