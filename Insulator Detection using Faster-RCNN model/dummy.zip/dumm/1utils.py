import cv2

def draw_bboxes(image, boxes):
    for box in boxes:
        xmin, ymin, xmax, ymax = box
        cv2.rectangle(image, (int(xmin), int(ymin)), (int(xmax), int(ymax)), (0, 255, 0), 2)
    return image
