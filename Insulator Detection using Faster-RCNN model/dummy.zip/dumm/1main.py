from dataset import InsulatorDataset
from model import get_model
from train import train_model
from inference import load_model, predict_and_display
from torch.utils.data import DataLoader
import torch

def collate_fn(batch):
    return tuple(zip(*batch))

def main():
    device = torch.device('cuda') if torch.cuda.is_available() else torch.device('cpu')

    dataset = InsulatorDataset(root_dir="path/to/dataset")
    data_loader = DataLoader(dataset, batch_size=2, shuffle=True, num_workers=0, collate_fn=collate_fn)
    
    model = get_model(num_classes=2)
    model.to(device)

    train_model(model, data_loader, device, num_epochs=10)

    model = load_model(device)
    predict_and_display(model, 'path/to/new/image.jpg', device)

if __name__ == '__main__':
    main()
